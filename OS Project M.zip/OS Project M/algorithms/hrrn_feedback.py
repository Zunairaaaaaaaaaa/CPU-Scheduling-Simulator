def hrrn(processes):
    """Highest Response Ratio Next Scheduling (Non-Preemptive)"""
    procs = [p.copy() for p in processes]
    n = len(procs)
    remaining = procs[:]
    current_time = 0
    timeline = []
    results = []

    while remaining:
        available = [p for p in remaining if p['arrival'] <= current_time]
        if not available:
            current_time = min(p['arrival'] for p in remaining)
            available = [p for p in remaining if p['arrival'] <= current_time]

        # Response Ratio = (Waiting Time + Burst Time) / Burst Time
        def response_ratio(p):
            waiting = current_time - p['arrival']
            return (waiting + p['burst']) / p['burst']

        chosen = max(available, key=response_ratio)
        remaining.remove(chosen)

        start = current_time
        end = start + chosen['burst']
        timeline.append({'id': chosen['id'], 'start': start, 'end': end})
        waiting = start - chosen['arrival']
        turnaround = end - chosen['arrival']
        response = start - chosen['arrival']
        results.append({
            'id': chosen['id'],
            'arrival': chosen['arrival'],
            'burst': chosen['burst'],
            'completion': end,
            'waiting': waiting,
            'turnaround': turnaround,
            'response': response
        })
        current_time = end

    results.sort(key=lambda x: x['id'])
    avg_waiting = sum(r['waiting'] for r in results) / len(results)
    avg_turnaround = sum(r['turnaround'] for r in results) / len(results)
    avg_response = sum(r['response'] for r in results) / len(results)

    return {
        'timeline': timeline,
        'results': results,
        'avg_waiting': avg_waiting,
        'avg_turnaround': avg_turnaround,
        'avg_response': avg_response
    }


def feedback(processes, quantum=1):
    """Feedback (Multi-level Feedback Queue) Scheduling"""
    procs = [p.copy() for p in processes]
    for p in procs:
        p['remaining'] = p['burst']
        p['level'] = 0
        p['response_time'] = None
        p['started'] = False

    procs.sort(key=lambda x: (x['arrival'], x['id']))

    # Multiple queues: queue[0] has highest priority
    MAX_LEVELS = 4
    queues = [[] for _ in range(MAX_LEVELS)]
    current_time = 0
    timeline = []
    results = []
    completed = []
    in_queue = set()
    n = len(procs)

    def enqueue_arrivals():
        for p in procs:
            if p['arrival'] <= current_time and p['id'] not in in_queue and p['remaining'] > 0 and p['id'] not in [r['id'] for r in results]:
                queues[p['level']].append(p)
                in_queue.add(p['id'])

    enqueue_arrivals()

    max_iter = sum(p['burst'] for p in procs) * 2 + 100
    itr = 0

    while len(completed) < n and itr < max_iter:
        itr += 1
        # Find highest priority non-empty queue
        chosen_queue = None
        for lvl in range(MAX_LEVELS):
            if queues[lvl]:
                chosen_queue = lvl
                break

        if chosen_queue is None:
            # Advance time to next arrival
            not_arrived = [p for p in procs if p['arrival'] > current_time and p['remaining'] > 0 and p['id'] not in [r['id'] for r in results]]
            if not_arrived:
                current_time = min(p['arrival'] for p in not_arrived)
                enqueue_arrivals()
            else:
                break
            continue

        current = queues[chosen_queue].pop(0)
        in_queue.discard(current['id'])

        if not current['started']:
            current['response_time'] = current_time - current['arrival']
            current['started'] = True

        exec_time = min(quantum, current['remaining'])
        start = current_time
        end = start + exec_time

        if timeline and timeline[-1]['id'] == current['id'] and timeline[-1]['end'] == start:
            timeline[-1]['end'] = end
        else:
            timeline.append({'id': current['id'], 'start': start, 'end': end})

        current['remaining'] -= exec_time
        current_time = end

        # Enqueue any newly arrived processes
        enqueue_arrivals()

        if current['remaining'] > 0:
            # Demote to lower priority queue
            next_level = min(current['level'] + 1, MAX_LEVELS - 1)
            current['level'] = next_level
            queues[next_level].append(current)
            in_queue.add(current['id'])
        else:
            completion = current_time
            turnaround = completion - current['arrival']
            waiting = turnaround - current['burst']
            results.append({
                'id': current['id'],
                'arrival': current['arrival'],
                'burst': current['burst'],
                'completion': completion,
                'waiting': waiting,
                'turnaround': turnaround,
                'response': current['response_time']
            })
            completed.append(current['id'])

    results.sort(key=lambda x: x['id'])
    if not results:
        return {'timeline': [], 'results': [], 'avg_waiting': 0, 'avg_turnaround': 0, 'avg_response': 0}

    avg_waiting = sum(r['waiting'] for r in results) / len(results)
    avg_turnaround = sum(r['turnaround'] for r in results) / len(results)
    avg_response = sum(r['response'] for r in results) / len(results)

    return {
        'timeline': timeline,
        'results': results,
        'avg_waiting': avg_waiting,
        'avg_turnaround': avg_turnaround,
        'avg_response': avg_response
    }
