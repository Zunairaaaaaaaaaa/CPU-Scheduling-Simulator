def srtf(processes):
    """Shortest Remaining Time First (Preemptive SJF)"""
    procs = [p.copy() for p in processes]
    for p in procs:
        p['remaining'] = p['burst']
        p['started'] = False
        p['response_time'] = None

    n = len(procs)
    current_time = 0
    completed_count = 0
    timeline = []
    results = []
    last_process = None

    max_time = sum(p['burst'] for p in procs) + max(p['arrival'] for p in procs) + 1

    while completed_count < n and current_time < max_time:
        available = [p for p in procs if p['arrival'] <= current_time and p['remaining'] > 0]
        if not available:
            current_time += 1
            continue

        chosen = min(available, key=lambda x: (x['remaining'], x['arrival'], x['id']))

        if not chosen['started']:
            chosen['response_time'] = current_time - chosen['arrival']
            chosen['started'] = True

        if timeline and timeline[-1]['id'] == chosen['id']:
            timeline[-1]['end'] += 1
        else:
            timeline.append({'id': chosen['id'], 'start': current_time, 'end': current_time + 1})

        chosen['remaining'] -= 1
        current_time += 1

        if chosen['remaining'] == 0:
            completion = current_time
            turnaround = completion - chosen['arrival']
            waiting = turnaround - chosen['burst']
            results.append({
                'id': chosen['id'],
                'arrival': chosen['arrival'],
                'burst': chosen['burst'],
                'completion': completion,
                'waiting': waiting,
                'turnaround': turnaround,
                'response': chosen['response_time']
            })
            completed_count += 1

    results.sort(key=lambda x: x['id'])
    avg_waiting = sum(r['waiting'] for r in results) / len(results)
    avg_turnaround = sum(r['turnaround'] for r in results) / len(results)
    avg_response = sum(r['response'] for r in results) / len(results)

    return {
        'timeline': timeline,
        'results': results,
        'avg_waiting': avg_waiting,
        'avg_turnaround': avg_turnaround,
        'avg_response': avg_response
    }
