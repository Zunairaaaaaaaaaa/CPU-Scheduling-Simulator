def sjf(processes):
    """Shortest Job First (Non-Preemptive) - also called SPN"""
    procs = [p.copy() for p in processes]
    n = len(procs)
    timeline = []
    results = []
    current_time = 0
    completed = []
    remaining = procs[:]

    while remaining:
        available = [p for p in remaining if p['arrival'] <= current_time]
        if not available:
            current_time = min(p['arrival'] for p in remaining)
            available = [p for p in remaining if p['arrival'] <= current_time]

        # Pick shortest burst; tie-break by arrival then id
        chosen = min(available, key=lambda x: (x['burst'], x['arrival'], x['id']))
        remaining.remove(chosen)

        start = current_time
        end = start + chosen['burst']
        timeline.append({'id': chosen['id'], 'start': start, 'end': end})
        waiting = start - chosen['arrival']
        turnaround = end - chosen['arrival']
        response = start - chosen['arrival']
        results.append({
            'id': chosen['id'],
            'arrival': chosen['arrival'],
            'burst': chosen['burst'],
            'start': start,
            'completion': end,
            'waiting': waiting,
            'turnaround': turnaround,
            'response': response
        })
        current_time = end

    results.sort(key=lambda x: x['id'])
    avg_waiting = sum(r['waiting'] for r in results) / len(results)
    avg_turnaround = sum(r['turnaround'] for r in results) / len(results)
    avg_response = sum(r['response'] for r in results) / len(results)

    return {
        'timeline': timeline,
        'results': results,
        'avg_waiting': avg_waiting,
        'avg_turnaround': avg_turnaround,
        'avg_response': avg_response
    }
