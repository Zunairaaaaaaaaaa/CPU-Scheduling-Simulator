def round_robin(processes, quantum):
    """Round Robin Scheduling"""
    procs = [p.copy() for p in processes]
    for p in procs:
        p['remaining'] = p['burst']
        p['response_time'] = None
        p['started'] = False

    procs.sort(key=lambda x: (x['arrival'], x['id']))

    queue = []
    current_time = 0
    timeline = []
    results = []
    completed = []
    added = set()
    n = len(procs)

    # Add processes that arrive at time 0
    for p in procs:
        if p['arrival'] <= current_time and p['id'] not in added:
            queue.append(p)
            added.add(p['id'])

    while queue or len(completed) < n:
        if not queue:
            # Jump to next arrival
            not_added = [p for p in procs if p['id'] not in added and p['remaining'] > 0]
            if not_added:
                current_time = min(p['arrival'] for p in not_added)
                for p in procs:
                    if p['arrival'] <= current_time and p['id'] not in added:
                        queue.append(p)
                        added.add(p['id'])
            if not queue:
                break

        current = queue.pop(0)

        if not current['started']:
            current['response_time'] = current_time - current['arrival']
            current['started'] = True

        exec_time = min(quantum, current['remaining'])
        start = current_time
        end = start + exec_time

        if timeline and timeline[-1]['id'] == current['id'] and timeline[-1]['end'] == start:
            timeline[-1]['end'] = end
        else:
            timeline.append({'id': current['id'], 'start': start, 'end': end})

        current['remaining'] -= exec_time
        current_time = end

        # Add newly arrived processes
        for p in procs:
            if p['arrival'] <= current_time and p['id'] not in added and p['remaining'] > 0:
                queue.append(p)
                added.add(p['id'])

        if current['remaining'] > 0:
            queue.append(current)
        else:
            completion = current_time
            turnaround = completion - current['arrival']
            waiting = turnaround - current['burst']
            results.append({
                'id': current['id'],
                'arrival': current['arrival'],
                'burst': current['burst'],
                'completion': completion,
                'waiting': waiting,
                'turnaround': turnaround,
                'response': current['response_time']
            })
            completed.append(current['id'])

    results.sort(key=lambda x: x['id'])
    avg_waiting = sum(r['waiting'] for r in results) / len(results)
    avg_turnaround = sum(r['turnaround'] for r in results) / len(results)
    avg_response = sum(r['response'] for r in results) / len(results)

    return {
        'timeline': timeline,
        'results': results,
        'avg_waiting': avg_waiting,
        'avg_turnaround': avg_turnaround,
        'avg_response': avg_response
    }
