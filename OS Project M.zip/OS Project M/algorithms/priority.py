def priority_scheduling(processes, preemptive=False):
    """Priority Scheduling (Non-Preemptive by default). Lower number = Higher priority."""
    procs = [p.copy() for p in processes]
    for p in procs:
        p['remaining'] = p['burst']
        p['response_time'] = None
        p['started'] = False

    n = len(procs)
    current_time = 0
    timeline = []
    results = []
    completed_ids = set()

    if not preemptive:
        remaining = procs[:]
        while remaining:
            available = [p for p in remaining if p['arrival'] <= current_time]
            if not available:
                current_time = min(p['arrival'] for p in remaining)
                available = [p for p in remaining if p['arrival'] <= current_time]

            chosen = min(available, key=lambda x: (x.get('priority', 0), x['arrival'], x['id']))
            remaining.remove(chosen)

            start = current_time
            end = start + chosen['burst']
            timeline.append({'id': chosen['id'], 'start': start, 'end': end})
            waiting = start - chosen['arrival']
            turnaround = end - chosen['arrival']
            response = start - chosen['arrival']
            results.append({
                'id': chosen['id'],
                'arrival': chosen['arrival'],
                'burst': chosen['burst'],
                'priority': chosen.get('priority', 0),
                'completion': end,
                'waiting': waiting,
                'turnaround': turnaround,
                'response': response
            })
            current_time = end
    else:
        # Preemptive priority
        max_time = sum(p['burst'] for p in procs) + max(p['arrival'] for p in procs) + 1
        while len(completed_ids) < n and current_time < max_time:
            available = [p for p in procs if p['arrival'] <= current_time and p['id'] not in completed_ids and p['remaining'] > 0]
            if not available:
                current_time += 1
                continue

            chosen = min(available, key=lambda x: (x.get('priority', 0), x['arrival'], x['id']))

            if not chosen['started']:
                chosen['response_time'] = current_time - chosen['arrival']
                chosen['started'] = True

            if timeline and timeline[-1]['id'] == chosen['id']:
                timeline[-1]['end'] += 1
            else:
                timeline.append({'id': chosen['id'], 'start': current_time, 'end': current_time + 1})

            chosen['remaining'] -= 1
            current_time += 1

            if chosen['remaining'] == 0:
                completion = current_time
                turnaround = completion - chosen['arrival']
                waiting = turnaround - chosen['burst']
                results.append({
                    'id': chosen['id'],
                    'arrival': chosen['arrival'],
                    'burst': chosen['burst'],
                    'priority': chosen.get('priority', 0),
                    'completion': completion,
                    'waiting': waiting,
                    'turnaround': turnaround,
                    'response': chosen['response_time']
                })
                completed_ids.add(chosen['id'])

    results.sort(key=lambda x: x['id'])
    avg_waiting = sum(r['waiting'] for r in results) / len(results)
    avg_turnaround = sum(r['turnaround'] for r in results) / len(results)
    avg_response = sum(r['response'] for r in results) / len(results)

    return {
        'timeline': timeline,
        'results': results,
        'avg_waiting': avg_waiting,
        'avg_turnaround': avg_turnaround,
        'avg_response': avg_response
    }
