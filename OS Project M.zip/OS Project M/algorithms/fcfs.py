def fcfs(processes):
    """First Come First Served Scheduling"""
    procs = sorted(processes, key=lambda x: (x['arrival'], x['id']))
    timeline = []
    current_time = 0
    results = []

    for p in procs:
        if current_time < p['arrival']:
            current_time = p['arrival']
        start = current_time
        end = start + p['burst']
        timeline.append({'id': p['id'], 'start': start, 'end': end})
        waiting = start - p['arrival']
        turnaround = end - p['arrival']
        response = start - p['arrival']
        results.append({
            'id': p['id'],
            'arrival': p['arrival'],
            'burst': p['burst'],
            'start': start,
            'completion': end,
            'waiting': waiting,
            'turnaround': turnaround,
            'response': response
        })
        current_time = end

    avg_waiting = sum(r['waiting'] for r in results) / len(results)
    avg_turnaround = sum(r['turnaround'] for r in results) / len(results)
    avg_response = sum(r['response'] for r in results) / len(results)

    return {
        'timeline': timeline,
        'results': results,
        'avg_waiting': avg_waiting,
        'avg_turnaround': avg_turnaround,
        'avg_response': avg_response
    }
