import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from algorithms.fcfs import fcfs
from algorithms.sjf import sjf
from algorithms.srtf import srtf
from algorithms.rr import round_robin
from algorithms.priority import priority_scheduling
from algorithms.hrrn_feedback import hrrn, feedback
from charts.gantt import draw_multi_gantt, draw_comparison_chart
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# ── Dark Theme Colors ────────────────────────────────────────────────────────
BG_DARK   = '#0f0f23'
BG_MID    = '#1a1a2e'
BG_CARD   = '#16213e'
ACCENT    = '#4fc3f7'
ACCENT2   = '#7c4dff'
SUCCESS   = '#66bb6a'
WARNING   = '#ffa726'
DANGER    = '#ef5350'
TEXT_PRI  = '#e8eaf6'
TEXT_SEC  = '#9fa8da'
BORDER    = '#2d2d54'

FONT_TITLE  = ('Segoe UI', 18, 'bold')
FONT_HEAD   = ('Segoe UI', 11, 'bold')
FONT_BODY   = ('Segoe UI', 9)
FONT_SMALL  = ('Segoe UI', 8)
FONT_MONO   = ('Consolas', 9)


class CPUSchedulerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('CPU Scheduling Simulator')
        self.geometry('1400x860')
        self.minsize(1100, 700)
        self.configure(bg=BG_DARK)
        self.resizable(True, True)

        self.processes = []
        self.process_counter = 1
        self.all_results = {}
        self._canvas_widgets = []

        self._setup_styles()
        self._build_ui()

    # ── Styles ────────────────────────────────────────────────────────────────
    def _setup_styles(self):
        style = ttk.Style(self)
        style.theme_use('clam')

        style.configure('Dark.TFrame', background=BG_DARK)
        style.configure('Card.TFrame', background=BG_CARD)
        style.configure('Mid.TFrame', background=BG_MID)

        style.configure('Title.TLabel', background=BG_DARK, foreground=ACCENT,
                        font=FONT_TITLE)
        style.configure('Head.TLabel', background=BG_CARD, foreground=TEXT_PRI,
                        font=FONT_HEAD)
        style.configure('Body.TLabel', background=BG_CARD, foreground=TEXT_SEC,
                        font=FONT_BODY)
        style.configure('Mid.TLabel', background=BG_MID, foreground=TEXT_SEC,
                        font=FONT_BODY)

        style.configure('Accent.TButton',
                        background=ACCENT2, foreground='white',
                        font=('Segoe UI', 10, 'bold'),
                        borderwidth=0, relief='flat', padding=(12, 8))
        style.map('Accent.TButton',
                  background=[('active', '#9c6fff'), ('pressed', '#6200ea')])

        style.configure('Success.TButton',
                        background=SUCCESS, foreground='white',
                        font=('Segoe UI', 10, 'bold'),
                        borderwidth=0, relief='flat', padding=(12, 8))
        style.map('Success.TButton',
                  background=[('active', '#81c784'), ('pressed', '#388e3c')])

        style.configure('Danger.TButton',
                        background=DANGER, foreground='white',
                        font=('Segoe UI', 9, 'bold'),
                        borderwidth=0, relief='flat', padding=(8, 6))
        style.map('Danger.TButton',
                  background=[('active', '#ef9a9a'), ('pressed', '#c62828')])

        style.configure('Dark.TEntry',
                        fieldbackground=BG_MID, foreground=TEXT_PRI,
                        insertcolor=ACCENT, bordercolor=BORDER,
                        font=FONT_BODY)

        # Treeview
        style.configure('Dark.Treeview',
                        background=BG_MID, foreground=TEXT_PRI,
                        fieldbackground=BG_MID, rowheight=24,
                        font=FONT_SMALL)
        style.configure('Dark.Treeview.Heading',
                        background=BG_CARD, foreground=ACCENT,
                        font=('Segoe UI', 9, 'bold'))
        style.map('Dark.Treeview',
                  background=[('selected', ACCENT2)],
                  foreground=[('selected', 'white')])

        style.configure('Dark.TCheckbutton',
                        background=BG_CARD, foreground=TEXT_SEC,
                        font=FONT_BODY)

        style.configure('Dark.TLabelframe',
                        background=BG_CARD, foreground=ACCENT,
                        font=FONT_HEAD, bordercolor=BORDER)
        style.configure('Dark.TLabelframe.Label',
                        background=BG_CARD, foreground=ACCENT,
                        font=FONT_HEAD)

        style.configure('Dark.TNotebook',
                        background=BG_DARK, bordercolor=BORDER)
        style.configure('Dark.TNotebook.Tab',
                        background=BG_MID, foreground=TEXT_SEC,
                        font=('Segoe UI', 9, 'bold'),
                        padding=(12, 6))
        style.map('Dark.TNotebook.Tab',
                  background=[('selected', BG_CARD), ('active', BG_CARD)],
                  foreground=[('selected', ACCENT)])

        style.configure('Dark.Vertical.TScrollbar',
                        background=BG_MID, troughcolor=BG_DARK,
                        arrowcolor=TEXT_SEC)
        style.configure('Dark.Horizontal.TScrollbar',
                        background=BG_MID, troughcolor=BG_DARK,
                        arrowcolor=TEXT_SEC)

    # ── UI Layout ─────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Header
        hdr = tk.Frame(self, bg=BG_MID, height=60)
        hdr.pack(fill='x', side='top')
        hdr.pack_propagate(False)

        tk.Label(hdr, text='⚙  CPU Scheduling Simulator',
                 bg=BG_MID, fg=ACCENT,
                 font=('Segoe UI', 16, 'bold')).pack(side='left', padx=20, pady=10)

        tk.Label(hdr, text='OS Project  |  Python + Tkinter + Matplotlib',
                 bg=BG_MID, fg=TEXT_SEC,
                 font=FONT_SMALL).pack(side='right', padx=20, pady=10)

        # Main pane
        pane = tk.PanedWindow(self, orient='horizontal',
                              bg=BG_DARK, sashwidth=6,
                              sashrelief='flat', sashpad=2)
        pane.pack(fill='both', expand=True, padx=8, pady=8)

        # Left panel
        left = tk.Frame(pane, bg=BG_DARK, width=340)
        pane.add(left, minsize=300)

        # Right panel (notebook)
        right = tk.Frame(pane, bg=BG_DARK)
        pane.add(right, minsize=600)

        self._build_left(left)
        self._build_right(right)

    # ── LEFT PANEL ────────────────────────────────────────────────────────────
    def _build_left(self, parent):
        parent.pack_propagate(False)

        # ── Process Input Card ────────────────────────────────────────────────
        input_card = tk.LabelFrame(parent, text='  Add Process  ',
                                   bg=BG_CARD, fg=ACCENT,
                                   font=('Segoe UI', 10, 'bold'),
                                   bd=1, relief='solid',
                                   highlightbackground=BORDER)
        input_card.pack(fill='x', padx=8, pady=(4, 4))

        fields_frame = tk.Frame(input_card, bg=BG_CARD)
        fields_frame.pack(fill='x', padx=10, pady=8)

        labels = ['Process ID', 'Arrival Time', 'Burst Time', 'Priority (opt)']
        self.entry_pid     = self._field(fields_frame, 'Process ID',     0, f'P{self.process_counter}')
        self.entry_arrival = self._field(fields_frame, 'Arrival Time',   1, '0')
        self.entry_burst   = self._field(fields_frame, 'Burst Time',     2, '5')
        self.entry_priority= self._field(fields_frame, 'Priority (opt)', 3, '1')

        btn_row = tk.Frame(input_card, bg=BG_CARD)
        btn_row.pack(fill='x', padx=10, pady=(0, 8))

        add_btn = tk.Button(btn_row, text='➕  Add Process',
                            bg=ACCENT2, fg='white',
                            font=('Segoe UI', 9, 'bold'),
                            bd=0, relief='flat', cursor='hand2',
                            activebackground='#9c6fff', activeforeground='white',
                            command=self._add_process)
        add_btn.pack(side='left', fill='x', expand=True, padx=(0, 4), ipady=6)

        clear_btn = tk.Button(btn_row, text='🗑 Clear All',
                              bg='#37474f', fg=TEXT_SEC,
                              font=('Segoe UI', 9, 'bold'),
                              bd=0, relief='flat', cursor='hand2',
                              activebackground='#546e7a', activeforeground='white',
                              command=self._clear_all)
        clear_btn.pack(side='right', ipady=6, ipadx=8)

        # Sample data button
        sample_btn = tk.Button(input_card, text='📋  Load Sample Data',
                               bg='#1e3a5f', fg=ACCENT,
                               font=('Segoe UI', 9),
                               bd=0, relief='flat', cursor='hand2',
                               activebackground='#2a4a7f', activeforeground=ACCENT,
                               command=self._load_sample)
        sample_btn.pack(fill='x', padx=10, pady=(0, 8), ipady=4)

        # ── Algorithm Options ─────────────────────────────────────────────────
        algo_card = tk.LabelFrame(parent, text='  Algorithm Options  ',
                                  bg=BG_CARD, fg=ACCENT,
                                  font=('Segoe UI', 10, 'bold'),
                                  bd=1, relief='solid',
                                  highlightbackground=BORDER)
        algo_card.pack(fill='x', padx=8, pady=(0, 4))

        opt_frame = tk.Frame(algo_card, bg=BG_CARD)
        opt_frame.pack(fill='x', padx=10, pady=6)

        # RR Quantum
        tk.Label(opt_frame, text='RR Quantum:', bg=BG_CARD,
                 fg=TEXT_SEC, font=FONT_BODY).grid(row=0, column=0, sticky='w', pady=3)
        self.rr_quantum = tk.StringVar(value='2')
        rr_e = tk.Entry(opt_frame, textvariable=self.rr_quantum, width=5,
                        bg=BG_MID, fg=TEXT_PRI, insertbackground=ACCENT,
                        font=FONT_MONO, bd=0, relief='flat')
        rr_e.grid(row=0, column=1, sticky='w', padx=8, pady=3)

        # Priority mode
        self.preemptive_priority = tk.BooleanVar(value=False)
        tk.Checkbutton(opt_frame, text='Preemptive Priority',
                       variable=self.preemptive_priority,
                       bg=BG_CARD, fg=TEXT_SEC,
                       selectcolor=BG_MID, activebackground=BG_CARD,
                       activeforeground=TEXT_PRI,
                       font=FONT_BODY).grid(row=1, column=0, columnspan=2,
                                             sticky='w', pady=3)

        # Algorithm checkboxes
        tk.Label(algo_card, text='Select Algorithms to Run:',
                 bg=BG_CARD, fg=TEXT_SEC, font=FONT_BODY).pack(anchor='w', padx=10, pady=(4, 0))

        chk_frame = tk.Frame(algo_card, bg=BG_CARD)
        chk_frame.pack(fill='x', padx=10, pady=4)

        self.algo_vars = {}
        algos = [
            ('FCFS', True),
            ('SJF (SPN)', True),
            ('SRTF', True),
            ('Round Robin', True),
            ('Priority', True),
            ('HRRN', True),
            ('Feedback q=1', True),
            ('Feedback q=2', True),
        ]
        for i, (name, default) in enumerate(algos):
            var = tk.BooleanVar(value=default)
            self.algo_vars[name] = var
            chk = tk.Checkbutton(chk_frame, text=name, variable=var,
                                  bg=BG_CARD, fg=TEXT_SEC,
                                  selectcolor=BG_MID, activebackground=BG_CARD,
                                  activeforeground=TEXT_PRI, font=FONT_SMALL)
            chk.grid(row=i // 2, column=i % 2, sticky='w', padx=4, pady=1)

        # ── Run Button ────────────────────────────────────────────────────────
        run_btn = tk.Button(parent, text='▶   RUN SIMULATION',
                            bg='#00897b', fg='white',
                            font=('Segoe UI', 12, 'bold'),
                            bd=0, relief='flat', cursor='hand2',
                            activebackground='#00acc1', activeforeground='white',
                            command=self._run_simulation)
        run_btn.pack(fill='x', padx=8, pady=6, ipady=10)

        # ── Process Table ─────────────────────────────────────────────────────
        proc_lbl = tk.Label(parent, text='Process Queue',
                            bg=BG_DARK, fg=ACCENT,
                            font=('Segoe UI', 10, 'bold'))
        proc_lbl.pack(anchor='w', padx=10, pady=(4, 0))

        table_frame = tk.Frame(parent, bg=BG_DARK)
        table_frame.pack(fill='both', expand=True, padx=8, pady=4)

        cols = ('ID', 'Arrival', 'Burst', 'Priority')
        self.proc_tree = ttk.Treeview(table_frame, columns=cols,
                                       show='headings', height=8,
                                       style='Dark.Treeview')
        for col in cols:
            self.proc_tree.heading(col, text=col)
            self.proc_tree.column(col, width=70, anchor='center')

        vsb = ttk.Scrollbar(table_frame, orient='vertical',
                             command=self.proc_tree.yview,
                             style='Dark.Vertical.TScrollbar')
        self.proc_tree.configure(yscrollcommand=vsb.set)

        self.proc_tree.pack(side='left', fill='both', expand=True)
        vsb.pack(side='right', fill='y')

        del_btn = tk.Button(parent, text='🗑 Delete Selected',
                            bg='#b71c1c', fg='white',
                            font=FONT_SMALL, bd=0, relief='flat',
                            cursor='hand2',
                            activebackground=DANGER,
                            command=self._delete_selected)
        del_btn.pack(fill='x', padx=8, pady=(0, 4), ipady=4)

    def _field(self, parent, label, row, default=''):
        tk.Label(parent, text=label + ':', bg=BG_CARD,
                 fg=TEXT_SEC, font=FONT_BODY).grid(row=row, column=0,
                                                    sticky='w', pady=3, padx=(0, 6))
        var = tk.StringVar(value=default)
        ent = tk.Entry(parent, textvariable=var, width=14,
                       bg=BG_MID, fg=TEXT_PRI, insertbackground=ACCENT,
                       font=FONT_MONO, bd=0, relief='flat',
                       highlightthickness=1, highlightcolor=ACCENT,
                       highlightbackground=BORDER)
        ent.grid(row=row, column=1, sticky='ew', pady=3)
        parent.columnconfigure(1, weight=1)
        return var

    # ── RIGHT PANEL ───────────────────────────────────────────────────────────
    def _build_right(self, parent):
        self.notebook = ttk.Notebook(parent, style='Dark.TNotebook')
        self.notebook.pack(fill='both', expand=True)

        # Tab 1: Gantt Charts
        self.gantt_tab = tk.Frame(self.notebook, bg=BG_DARK)
        self.notebook.add(self.gantt_tab, text='  📊 Gantt Charts  ')

        # Tab 2: Comparison
        self.compare_tab = tk.Frame(self.notebook, bg=BG_DARK)
        self.notebook.add(self.compare_tab, text='  📈 Comparison  ')

        # Tab 3: Results Table
        self.table_tab = tk.Frame(self.notebook, bg=BG_DARK)
        self.notebook.add(self.table_tab, text='  📋 Results Table  ')

        # Tab 4: Summary
        self.summary_tab = tk.Frame(self.notebook, bg=BG_DARK)
        self.notebook.add(self.summary_tab, text='  🏆 Summary  ')

        self._build_gantt_tab()
        self._build_compare_tab()
        self._build_table_tab()
        self._build_summary_tab()

    def _build_gantt_tab(self):
        lbl = tk.Label(self.gantt_tab,
                       text='Run simulation to see Gantt charts for all algorithms.',
                       bg=BG_DARK, fg=TEXT_SEC, font=FONT_BODY)
        lbl.pack(pady=40)
        self.gantt_placeholder = lbl

        self.gantt_frame = tk.Frame(self.gantt_tab, bg=BG_DARK)
        self.gantt_scroll_canvas = None

    def _build_compare_tab(self):
        lbl = tk.Label(self.compare_tab,
                       text='Run simulation to see comparison chart.',
                       bg=BG_DARK, fg=TEXT_SEC, font=FONT_BODY)
        lbl.pack(pady=40)
        self.compare_placeholder = lbl
        self.compare_frame = tk.Frame(self.compare_tab, bg=BG_DARK)

    def _build_table_tab(self):
        self.table_notebook = ttk.Notebook(self.table_tab, style='Dark.TNotebook')
        self.table_notebook.pack(fill='both', expand=True, padx=4, pady=4)

    def _build_summary_tab(self):
        self.summary_text = tk.Text(self.summary_tab, bg=BG_MID, fg=TEXT_PRI,
                                     font=FONT_MONO, bd=0, relief='flat',
                                     padx=12, pady=12, state='disabled',
                                     wrap='word')
        vsb = ttk.Scrollbar(self.summary_tab, orient='vertical',
                             command=self.summary_text.yview,
                             style='Dark.Vertical.TScrollbar')
        self.summary_text.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self.summary_text.pack(fill='both', expand=True, padx=4, pady=4)

    # ── Actions ───────────────────────────────────────────────────────────────
    def _add_process(self):
        try:
            pid = self.entry_pid.get().strip()
            arrival = int(self.entry_arrival.get().strip())
            burst = int(self.entry_burst.get().strip())
            priority_str = self.entry_priority.get().strip()
            priority = int(priority_str) if priority_str else 1

            if not pid:
                messagebox.showerror('Error', 'Process ID cannot be empty.')
                return
            if burst <= 0:
                messagebox.showerror('Error', 'Burst time must be > 0.')
                return
            if arrival < 0:
                messagebox.showerror('Error', 'Arrival time cannot be negative.')
                return
            if any(p['id'] == pid for p in self.processes):
                messagebox.showerror('Error', f'Process ID "{pid}" already exists.')
                return

            proc = {'id': pid, 'arrival': arrival, 'burst': burst, 'priority': priority}
            self.processes.append(proc)
            self.proc_tree.insert('', 'end', values=(pid, arrival, burst, priority))

            self.process_counter += 1
            self.entry_pid.set(f'P{self.process_counter}')
            self.entry_arrival.set('0')
            self.entry_burst.set('5')
            self.entry_priority.set('1')

        except ValueError:
            messagebox.showerror('Error', 'Please enter valid integer values.')

    def _delete_selected(self):
        selected = self.proc_tree.selection()
        for item in selected:
            vals = self.proc_tree.item(item, 'values')
            pid = vals[0]
            self.processes = [p for p in self.processes if p['id'] != pid]
            self.proc_tree.delete(item)

    def _clear_all(self):
        self.processes.clear()
        for item in self.proc_tree.get_children():
            self.proc_tree.delete(item)
        self.process_counter = 1
        self.entry_pid.set('P1')

    def _load_sample(self):
        self._clear_all()
        sample = [
            {'id': 'P1', 'arrival': 0, 'burst': 8, 'priority': 3},
            {'id': 'P2', 'arrival': 1, 'burst': 4, 'priority': 1},
            {'id': 'P3', 'arrival': 2, 'burst': 9, 'priority': 4},
            {'id': 'P4', 'arrival': 3, 'burst': 5, 'priority': 2},
            {'id': 'P5', 'arrival': 4, 'burst': 2, 'priority': 5},
        ]
        for p in sample:
            self.processes.append(p)
            self.proc_tree.insert('', 'end',
                                   values=(p['id'], p['arrival'], p['burst'], p['priority']))
        self.process_counter = 6
        self.entry_pid.set('P6')

    def _run_simulation(self):
        if not self.processes:
            messagebox.showerror('Error', 'Please add at least one process first.')
            return

        try:
            quantum = int(self.rr_quantum.get())
        except ValueError:
            messagebox.showerror('Error', 'RR Quantum must be an integer.')
            return

        procs = self.processes

        self.all_results = {}

        try:
            if self.algo_vars.get('FCFS', tk.BooleanVar(value=False)).get():
                self.all_results['FCFS'] = fcfs(procs)

            if self.algo_vars.get('SJF (SPN)', tk.BooleanVar(value=False)).get():
                self.all_results['SJF (SPN)'] = sjf(procs)

            if self.algo_vars.get('SRTF', tk.BooleanVar(value=False)).get():
                self.all_results['SRTF'] = srtf(procs)

            if self.algo_vars.get('Round Robin', tk.BooleanVar(value=False)).get():
                self.all_results[f'Round Robin q={quantum}'] = round_robin(procs, quantum)

            if self.algo_vars.get('Priority', tk.BooleanVar(value=False)).get():
                mode = 'Preemptive' if self.preemptive_priority.get() else 'Non-Preempt'
                self.all_results[f'Priority ({mode})'] = priority_scheduling(
                    procs, preemptive=self.preemptive_priority.get())

            if self.algo_vars.get('HRRN', tk.BooleanVar(value=False)).get():
                self.all_results['HRRN'] = hrrn(procs)

            if self.algo_vars.get('Feedback q=1', tk.BooleanVar(value=False)).get():
                self.all_results['Feedback q=1'] = feedback(procs, quantum=1)

            if self.algo_vars.get('Feedback q=2', tk.BooleanVar(value=False)).get():
                self.all_results['Feedback q=2'] = feedback(procs, quantum=2)

        except Exception as e:
            messagebox.showerror('Algorithm Error', str(e))
            return

        if not self.all_results:
            messagebox.showwarning('Warning', 'No algorithms selected.')
            return

        self._update_gantt_tab()
        self._update_compare_tab()
        self._update_table_tab()
        self._update_summary_tab()
        self.notebook.select(0)

    # ── Update Tabs ───────────────────────────────────────────────────────────
    def _clear_frame(self, frame):
        for widget in frame.winfo_children():
            widget.destroy()

    def _update_gantt_tab(self):
        self._clear_frame(self.gantt_tab)

        # Scrollable container
        outer = tk.Frame(self.gantt_tab, bg=BG_DARK)
        outer.pack(fill='both', expand=True)

        canvas = tk.Canvas(outer, bg=BG_DARK, highlightthickness=0)
        vsb = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview,
                             style='Dark.Vertical.TScrollbar')
        hsb = ttk.Scrollbar(outer, orient='horizontal', command=canvas.xview,
                             style='Dark.Horizontal.TScrollbar')

        scroll_frame = tk.Frame(canvas, bg=BG_DARK)
        scroll_frame.bind('<Configure>',
                          lambda e: canvas.configure(scrollregion=canvas.bbox('all')))

        canvas.create_window((0, 0), window=scroll_frame, anchor='nw')
        canvas.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        vsb.pack(side='right', fill='y')
        hsb.pack(side='bottom', fill='x')
        canvas.pack(side='left', fill='both', expand=True)

        fig = draw_multi_gantt(scroll_frame, self.all_results, self.processes)
        fig_canvas = FigureCanvasTkAgg(fig, master=scroll_frame)
        fig_canvas.draw()
        fig_canvas.get_tk_widget().pack(fill='both', expand=True, padx=4, pady=4)

        # Mouse scroll
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        canvas.bind_all('<MouseWheel>', _on_mousewheel)

    def _update_compare_tab(self):
        self._clear_frame(self.compare_tab)

        fig = draw_comparison_chart(self.compare_tab, self.all_results)
        fig_canvas = FigureCanvasTkAgg(fig, master=self.compare_tab)
        fig_canvas.draw()
        fig_canvas.get_tk_widget().pack(fill='both', expand=True, padx=4, pady=4)

    def _update_table_tab(self):
        self._clear_frame(self.table_tab)

        nb = ttk.Notebook(self.table_tab, style='Dark.TNotebook')
        nb.pack(fill='both', expand=True, padx=4, pady=4)

        for algo_name, result in self.all_results.items():
            tab = tk.Frame(nb, bg=BG_DARK)
            nb.add(tab, text=f'  {algo_name}  ')
            self._build_result_table(tab, result, algo_name)

    def _build_result_table(self, parent, result, algo_name):
        # Stats bar
        stats = tk.Frame(parent, bg=BG_CARD)
        stats.pack(fill='x', padx=4, pady=4)

        for label, key, color in [
            ('⏱ Avg Waiting', 'avg_waiting', WARNING),
            ('🔄 Avg Turnaround', 'avg_turnaround', ACCENT),
            ('⚡ Avg Response', 'avg_response', SUCCESS),
        ]:
            card = tk.Frame(stats, bg=BG_MID, bd=0)
            card.pack(side='left', padx=6, pady=6, ipadx=12, ipady=6)
            tk.Label(card, text=label, bg=BG_MID, fg=TEXT_SEC,
                     font=FONT_SMALL).pack()
            tk.Label(card, text=f"{result.get(key, 0):.2f}",
                     bg=BG_MID, fg=color,
                     font=('Segoe UI', 13, 'bold')).pack()

        # Table
        cols = ('Process', 'Arrival', 'Burst', 'Start/Completion', 'Completion',
                'Waiting', 'Turnaround', 'Response')
        tree = ttk.Treeview(parent, columns=cols, show='headings',
                             style='Dark.Treeview')
        widths = [65, 65, 55, 100, 85, 65, 85, 70]
        for col, w in zip(cols, widths):
            tree.heading(col, text=col)
            tree.column(col, width=w, anchor='center')

        # Alternate row colors
        tree.tag_configure('odd', background='#1e2a3a')
        tree.tag_configure('even', background=BG_MID)

        for i, r in enumerate(result.get('results', [])):
            tag = 'odd' if i % 2 == 0 else 'even'
            start_val = r.get('start', r.get('completion', 0) - r.get('burst', 0))
            tree.insert('', 'end', tags=(tag,),
                        values=(r['id'], r['arrival'], r['burst'],
                                start_val, r['completion'],
                                r['waiting'], r['turnaround'],
                                r.get('response', 0)))

        vsb = ttk.Scrollbar(parent, orient='vertical', command=tree.yview,
                             style='Dark.Vertical.TScrollbar')
        tree.configure(yscrollcommand=vsb.set)

        hsb = ttk.Scrollbar(parent, orient='horizontal', command=tree.xview,
                             style='Dark.Horizontal.TScrollbar')
        tree.configure(xscrollcommand=hsb.set)

        hsb.pack(side='bottom', fill='x', padx=4)
        vsb.pack(side='right', fill='y', padx=(0, 4))
        tree.pack(fill='both', expand=True, padx=4, pady=(0, 4))

    def _update_summary_tab(self):
        self.summary_text.configure(state='normal')
        self.summary_text.delete('1.0', 'end')

        lines = []
        lines.append('=' * 60)
        lines.append('   CPU SCHEDULING SIMULATION — SUMMARY REPORT')
        lines.append('=' * 60)
        lines.append(f'\nProcesses: {len(self.processes)}')
        lines.append('  ' + '  '.join(p['id'] for p in self.processes))
        lines.append('')

        # Header row
        lines.append(f"{'Algorithm':<22} {'Avg Wait':>10} {'Avg TAT':>10} {'Avg Resp':>10}")
        lines.append('-' * 56)

        best_wait = min(self.all_results.values(), key=lambda x: x['avg_waiting'])
        best_tat  = min(self.all_results.values(), key=lambda x: x['avg_turnaround'])
        best_resp = min(self.all_results.values(), key=lambda x: x['avg_response'])

        for name, r in self.all_results.items():
            w = f"{r['avg_waiting']:.2f}"
            t = f"{r['avg_turnaround']:.2f}"
            resp = f"{r['avg_response']:.2f}"
            star_w = ' ★' if r is best_wait else ''
            star_t = ' ★' if r is best_tat else ''
            star_r = ' ★' if r is best_resp else ''
            lines.append(f"{name:<22} {w+star_w:>10} {t+star_t:>10} {resp+star_r:>10}")

        lines.append('')
        lines.append('★ = Best performer in that metric')
        lines.append('')
        lines.append('─' * 56)

        # Find overall best
        scores = {name: 0 for name in self.all_results}
        for name, r in self.all_results.items():
            if r is best_wait:
                scores[name] += 1
            if r is best_tat:
                scores[name] += 1
            if r is best_resp:
                scores[name] += 1

        top = max(scores, key=scores.get)
        lines.append(f'\n🏆  Overall Best Algorithm: {top}')
        lines.append(f'    (Best in {scores[top]}/3 metrics)')

        self.summary_text.insert('1.0', '\n'.join(lines))
        self.summary_text.configure(state='disabled')
