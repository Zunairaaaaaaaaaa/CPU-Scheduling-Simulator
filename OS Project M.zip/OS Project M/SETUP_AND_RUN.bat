@echo off
echo ============================================
echo  CPU Scheduling Simulator - Setup
echo ============================================
echo.
echo Installing required libraries...
pip install matplotlib
echo.
echo ============================================
echo  Setup complete! Launching app...
echo ============================================
echo.
python main.py
pause
