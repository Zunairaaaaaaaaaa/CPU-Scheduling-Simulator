"""
CPU Scheduling Simulator
========================
OS University Project

Algorithms implemented:
  - FCFS (First Come First Served)
  - SJF / SPN (Shortest Job First)
  - SRTF (Shortest Remaining Time First)
  - Round Robin (configurable quantum)
  - Priority Scheduling (preemptive & non-preemptive)
  - HRRN (Highest Response Ratio Next)
  - Feedback / MLFQ (Multi-Level Feedback Queue)

Run:
    python main.py
"""

import sys
import os

# Ensure project root is in path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gui.interface import CPUSchedulerApp


def main():
    app = CPUSchedulerApp()
    app.mainloop()


if __name__ == '__main__':
    main()
