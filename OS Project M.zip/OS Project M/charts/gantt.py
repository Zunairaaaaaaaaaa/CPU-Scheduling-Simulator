import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib
matplotlib.use('TkAgg')

# Color palette for processes
PROCESS_COLORS = [
    '#4FC3F7', '#81C784', '#FFB74D', '#F06292', '#CE93D8',
    '#80CBC4', '#FFCC02', '#FF8A65', '#90CAF9', '#A5D6A7',
    '#FFF176', '#FFAB91', '#B39DDB', '#80DEEA', '#EF9A9A'
]

IDLE_COLOR = '#444444'


def get_color(pid, color_map):
    if pid not in color_map:
        idx = len(color_map) % len(PROCESS_COLORS)
        color_map[pid] = PROCESS_COLORS[idx]
    return color_map[pid]


def draw_gantt_chart(ax, timeline, title, color_map, show_labels=True):
    """Draw a single Gantt chart row on given axes."""
    ax.set_facecolor('#1a1a2e')
    ax.set_title(title, fontsize=9, color='white', pad=4, fontweight='bold')
    ax.set_yticks([])
    ax.tick_params(colors='white', labelsize=7)
    ax.spines['bottom'].set_color('#555')
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)

    if not timeline:
        return

    max_time = max(seg['end'] for seg in timeline)

    for seg in timeline:
        pid = seg['id']
        color = get_color(pid, color_map)
        width = seg['end'] - seg['start']
        bar = ax.barh(0, width, left=seg['start'], height=0.6,
                      color=color, edgecolor='#1a1a2e', linewidth=0.8)
        if show_labels and width > 0.5:
            ax.text(seg['start'] + width / 2, 0, pid,
                    ha='center', va='center', fontsize=7,
                    color='white', fontweight='bold')

    # Time markers
    ax.set_xlim(0, max_time)
    ax.set_xticks(range(0, max_time + 1, max(1, max_time // 10)))
    ax.set_ylim(-0.5, 0.5)


def draw_multi_gantt(parent_frame, all_results, processes):
    """Draw all algorithm Gantt charts stacked vertically in the given frame."""
    import tkinter as tk
    color_map = {}

    algo_names = list(all_results.keys())
    n_algos = len(algo_names)

    fig, axes = plt.subplots(n_algos, 1,
                             figsize=(12, max(3, n_algos * 1.1)),
                             facecolor='#0f0f23')
    fig.subplots_adjust(hspace=0.7, left=0.01, right=0.99, top=0.97, bottom=0.06)

    if n_algos == 1:
        axes = [axes]

    for ax, name in zip(axes, algo_names):
        timeline = all_results[name].get('timeline', [])
        draw_gantt_chart(ax, timeline, name, color_map)

    # Legend
    legend_patches = []
    for pid, color in color_map.items():
        legend_patches.append(mpatches.Patch(color=color, label=pid))
    if legend_patches:
        fig.legend(handles=legend_patches, loc='lower center',
                   ncol=min(len(legend_patches), 8),
                   fontsize=7, facecolor='#1a1a2e', labelcolor='white',
                   framealpha=0.8, bbox_to_anchor=(0.5, 0))

    return fig


def draw_comparison_chart(parent_frame, all_results):
    """Draw grouped bar chart comparing all algorithms."""
    algo_names = list(all_results.keys())
    waiting = [all_results[a]['avg_waiting'] for a in algo_names]
    turnaround = [all_results[a]['avg_turnaround'] for a in algo_names]
    response = [all_results[a]['avg_response'] for a in algo_names]

    x = range(len(algo_names))
    width = 0.25

    fig, ax = plt.subplots(figsize=(11, 4.5), facecolor='#0f0f23')
    ax.set_facecolor('#1a1a2e')

    bars1 = ax.bar([i - width for i in x], waiting, width,
                   label='Waiting Time', color='#ef5350', edgecolor='#1a1a2e', linewidth=0.5)
    bars2 = ax.bar(list(x), turnaround, width,
                   label='Turnaround Time', color='#42a5f5', edgecolor='#1a1a2e', linewidth=0.5)
    bars3 = ax.bar([i + width for i in x], response, width,
                   label='Response Time', color='#66bb6a', edgecolor='#1a1a2e', linewidth=0.5)

    def autolabel(bars):
        for bar in bars:
            h = bar.get_height()
            if h > 0:
                ax.annotate(f'{h:.1f}',
                            xy=(bar.get_x() + bar.get_width() / 2, h),
                            xytext=(0, 3), textcoords='offset points',
                            ha='center', va='bottom', fontsize=7, color='white')

    autolabel(bars1)
    autolabel(bars2)
    autolabel(bars3)

    ax.set_xticks(list(x))
    ax.set_xticklabels(algo_names, rotation=20, ha='right', fontsize=8, color='white')
    ax.set_ylabel('Time (ms)', color='white', fontsize=9)
    ax.set_title('Scheduling Algorithms Comparison', color='white', fontsize=11, fontweight='bold', pad=10)
    ax.tick_params(colors='white', labelsize=8)
    ax.spines['bottom'].set_color('#555')
    ax.spines['left'].set_color('#555')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.yaxis.grid(True, color='#333', linestyle='--', alpha=0.5)
    ax.set_axisbelow(True)

    legend = ax.legend(facecolor='#1a1a2e', labelcolor='white',
                       framealpha=0.9, fontsize=8, loc='upper right')

    fig.tight_layout()
    return fig
